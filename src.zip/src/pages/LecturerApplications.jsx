import "../styles/toDashboard.css"
import Sidebar from "../components/Sidebar"
import Topbar from "../components/Topbar"
import { useEffect, useMemo, useState } from "react"
import { LecturerRequestAPI } from "../api/api"

export default function LecturerApplications() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const load = async () => {
    setError("")
    try {
      setLoading(true)
      const list = await LecturerRequestAPI.queue()
      setRows(Array.isArray(list) ? list : [])
    } catch (e) {
      setError(e?.message || "Failed to load approval queue")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const pending = useMemo(() => {
    const out = []
    for (const r of rows || []) {
      const items = Array.isArray(r?.items) ? r.items : []
      for (const it of items) {
        const st = String(it?.itemStatus || "")
        if (st === "PENDING_LECTURER_APPROVAL") {
          out.push({ ...r, _item: it })
        }
      }
    }
    return out.sort((a, b) => (b.requestId || 0) - (a.requestId || 0))
  }, [rows])

  const fmt = (d) => (d ? String(d) : "-")

  const renderItems = (r) => {
    const it = r?._item
    if (!it) return "-"
    return (
      <div>
        {it.equipmentName || `Equipment #${it.equipmentId}`} × {it.quantity}
      </div>
    )
  }

  const requesterText = (r) => {
    return r.requesterRegNo || r.requesterFullName || "-"
  }

  const actApprove = async (requestItemId) => {
    setError("")
    try {
      await LecturerRequestAPI.approveItem(requestItemId)
      await load()
    } catch (e) {
      setError(e?.message || "Approve failed")
    }
  }

  const actReject = async (requestItemId) => {
    const reason = window.prompt("Reason (optional):") || ""
    setError("")
    try {
      await LecturerRequestAPI.rejectItem(requestItemId, reason.trim())
      await load()
    } catch (e) {
      setError(e?.message || "Reject failed")
    }
  }

  return (
    <div className="dashboard-container">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <div className="main-content">
        <Topbar onMenuClick={() => setSidebarOpen(true)} />

        <div className="content">
          <h2 style={{ marginBottom: "15px" }}>Applications</h2>

          {error && <div className="error-message" style={{ color: "red", marginBottom: 10 }}>{error}</div>}

          {pending.length === 0 && !loading && (
            <div style={{ textAlign: "center", color: "#777" }}>No pending applications</div>
          )}
          {pending.map((r) => (
            <div key={`${r.requestId}-${r?._item?.requestItemId}`} className="history-card">
              <div className="history-grid">
                <div className="history-left">
                  <div><strong>Request ID:</strong> {r.requestId}</div>
                  <div><strong>Requester:</strong> {requesterText(r)}</div>
                  <div><strong>Lab:</strong> {r.labName || "-"}</div>
                </div>
                <div className="history-right">
                  <div><strong>Item:</strong> {renderItems(r)}</div>
                  <div><strong>From:</strong> {fmt(r.fromDate)}</div>
                  <div><strong>To:</strong> {fmt(r.toDate)}</div>
                </div>
              </div>
              <div className="history-actions">
                <button type="button" className="btn-submit small" onClick={() => actApprove(r?._item?.requestItemId)}>
                  Approve
                </button>
                <button type="button" className="btn-cancel small" onClick={() => actReject(r?._item?.requestItemId)}>
                  Reject
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}